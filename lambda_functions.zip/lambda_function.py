import json
import boto3
import os

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        # Log the received event for debugging
        print("Received event:", json.dumps(event))

        # Check if 'body' exists in the event and parse it
        body = event.get('body')
        if not body:
            raise ValueError("Missing 'body' in the event")

        # Parse the body as JSON
        body_data = json.loads(body)
        
        # Ensure the 'string' field is in the body
        dynamic_string = body_data.get('string')
        if not dynamic_string:
            raise ValueError("Missing 'string' in the request body")

        # Update DynamoDB
        table = dynamodb.Table(os.environ['TABLE_NAME'])
        table.put_item(Item={'id': '1', 'value': dynamic_string})

        # Update S3 HTML file
        html_content = f"<h1>The saved string is {dynamic_string}</h1>"
        s3.put_object(
            Bucket=os.environ['BUCKET_NAME'],
            Key='index.html',
            Body=html_content,
            ContentType='text/html'
        )

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'String updated successfully'})
        }

    except Exception as e:
        # Log the error and return a 500 status code with the error message
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': f"An error occurred: {str(e)}"})
        }
